<div>
    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
</div><?php /**PATH C:\wamp64\www\websaels-app\resources\views\components\testlayout.blade.php ENDPATH**/ ?>